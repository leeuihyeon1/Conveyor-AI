import time
import serial
import requests
import numpy
import threading
from io import BytesIO
import cv2
import os
from datetime import datetime
import sqlite3
from flask import Flask, Response, render_template
import json
from requests.auth import HTTPBasicAuth
app = Flask(__name__)

# 시리얼 통신 설정
SERIAL_PORT = "/dev/ttyACM0"
BAUD_RATE = 9600

# API endpoint 설정
api_url = "https://suite-endpoint-api-apne2.superb-ai.com/endpoints/b2a6115e-1487-4613-8419-96563878b36b/inference"
ACCESS_KEY = "9yIZaEry9A2bzfT3hpx1l3yZLllSESnH49kgUyei"

# 이벤트 설정
ir_triggered_event = threading.Event()
terminate_event = threading.Event()

# 정상 제품과 불량 제품의 기준 추가
target_counts_normal = {
    'RASBERRY PICO': 1,
    'HOLE': 4, 
    'CHIPSET': 1,
    'USB': 1,
    'OSCILLATOR': 1,
    'BOOTSEL': 1
}

target_counts_with_broken = {
    'RASBERRY PICO': 1,
    'HOLE': 4, 
    'CHIPSET': 1,
    'OSCILLATOR': 1,
    'BROKEN_USB': 1,
    'BOOTSEL': 1
}

# Gradio 인터페이스를 위한 전역 변수
latest_detection_image = None
detection_status = None

# 공유 데이터를 위한 전역 딕셔너리
shared_data = {
    'current_frame': None,
    'detection_frame': None,
    'status': None
}

def crop_img(img, size_dict):
    x = 50       # 왼쪽에서 50픽셀 지점부터 시작
    y = 20       # 위에서 20픽셀 지점부터 시작
    w = 500      # 너비 600픽셀
    h = 900      # 높이 900픽셀
    img = img[y : y + h, x : x + w]
    return img


def process_frame(img, result):
    """프레임에 바운딩 박스와 정보를 그리는 함수"""
    # 객체 카운트 초기화
    object_counts = {}
    
    # 색상 매핑 정의
    colors = {
        'RASBERRY PICO': (0, 255, 0),    # 초록색
        'HOLE': (255, 0, 0),             # 파란색 
        'CHIPSET': (0, 0, 255),          # 빨간색
        'BOOTSEL': (255, 255, 0),        # 청록색
        'USB': (255, 0, 255),            # 분홍색
        'OSCILLATOR': (128, 0, 128),     # 보라색
        'BROKEN_USB': (0, 128, 128)      # 청록색
    }
    
    # 객체 카운트 계산
    for obj in result['objects']:
        if obj['score'] > 0.5:
            class_name = obj['class']
            object_counts[class_name] = object_counts.get(class_name, 0) + 1
    
    # 좌측 상단에 객체 개수 표시
    y_offset = 30
    for class_name, count in object_counts.items():
        text = f"{class_name}: {count}"
        cv2.putText(img, text, (10, y_offset), cv2.FONT_HERSHEY_SIMPLEX, 
                   0.5, colors.get(class_name, (255,255,255)), 2, cv2.LINE_AA)
        y_offset += 20
    
    # 바운딩 박스와 레이블 그리기
    for obj in result['objects']:
        if obj['score'] > 0.5:
            start_point = (obj['box'][0], obj['box'][1])
            end_point = (obj['box'][2], obj['box'][3])
            class_name = obj['class']
            color = colors.get(class_name, (255,255,255))
            
            # 바운딩 박스 그리기
            cv2.rectangle(img, start_point, end_point, color, 2)
            
            # 클래스명과 신뢰도 표시
            text = f"{class_name} ({obj['score']:.2f})"
            position = (obj['box'][0], obj['box'][1] - 10)
            cv2.putText(img, text, position, cv2.FONT_HERSHEY_SIMPLEX, 
                       0.5, color, 2, cv2.LINE_AA)
    
    # 제품 상태 판정
    is_normal = True
    is_broken = True
    
    # 정상 제품 기준 확인
    for class_name, target_count in target_counts_normal.items():
        if object_counts.get(class_name, 0) != target_count:
            is_normal = False
            break
    
    # 불량 제품 기준 확인
    for class_name, target_count in target_counts_with_broken.items():
        if object_counts.get(class_name, 0) != target_count:
            is_broken = False
            break
    
    # 판정 결과 표시
    if is_normal:
        status = "정상 제품"
        status_color = (0, 255, 0)  # 초록색
    elif is_broken:
        status = "불량 제품"
        status_color = (0, 0, 255)  # 빨간색
    else:
        status = "미확인"
        status_color = (0, 255, 255)  # 노란색
    
    # 상태 텍스트 표시
    cv2.putText(img, f"상태: {status}", (10, img.shape[0] - 20), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2, cv2.LINE_AA)
    
    return img, status


def inference_reqeust(img: numpy.array, api_url: str):
    """이미지를 API로 전송하여 추론을 요청합니다."""
    _, img_encoded = cv2.imencode(".jpg", img)
    
    response = requests.post(
        url=api_url,
        auth=HTTPBasicAuth("kdt2024_1-19", ACCESS_KEY),
        headers={"Content-Type": "image/jpeg"},
        data=img_encoded.tobytes(),
    )
    
    return response.json()


def serial_read_thread(ser):
    """IR 센서 감지 신호를 기다리는 스레드"""
    while not terminate_event.is_set():
        try:
            data = ser.read()
            if data:
                print(f"수신된 데이터: {data}")  # 실제로 어떤 데이터가 오는지 확인
                if data == b"0":
                    print("IR Sensor Triggered!")
                    ir_triggered_event.set()
        except serial.SerialException as e:
            print(f"Serial read error: {e}")
            break
        except Exception as e:
            print(f"Unexpected error in serial thread: {e}")
            break
        time.sleep(0.01)


def init_database():
    """데이터베이스 초기화 및 테이블 생성"""
    try:
        conn = sqlite3.connect('product_quality.db')
        cursor = conn.cursor()
        
        # 제품품질 테이블 생성
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS 제품품질 (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                datetime TEXT NOT NULL,
                상태 TEXT NOT NULL,
                불량유형 TEXT,
                객체수량 TEXT
            )
        ''')
        
        conn.commit()
        print("데이터베이스 초기화 완료")
        return conn
    except sqlite3.Error as e:
        print(f"데이터베이스 초기화 오류: {e}")
        return None


def save_quality_data(conn, status, object_counts):
    """품질 데이터를 데이터베이스에 저장"""
    try:
        cursor = conn.cursor()
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 불량 유형 확인
        defect_type = None
        if status == "불량 제품":
            # 객체 수량을 비교하여 불량 유형 파악
            if 'BROKEN_USB' in object_counts:
                defect_type = "USB 손상"
            else:
                missing_parts = []
                for part, target_count in target_counts_normal.items():
                    actual_count = object_counts.get(part, 0)
                    if actual_count != target_count:
                        missing_parts.append(f"{part}({actual_count}/{target_count})")
                if missing_parts:
                    defect_type = "부품 누락: " + ", ".join(missing_parts)
        
        # 객체 수량을 문자열로 변환
        counts_str = ", ".join([f"{k}:{v}" for k, v in object_counts.items()])
        
        cursor.execute('''
            INSERT INTO 제품품질 (datetime, 상태, 불량유형, 객체수량)
            VALUES (?, ?, ?, ?)
        ''', (current_time, status, defect_type, counts_str))
        
        conn.commit()
        print(f"품질 데이터 저장 완료: {status}")
    except sqlite3.Error as e:
        print(f"데이터 저장 오류: {e}")

@app.route('/')
def index():
    return render_template('index.html')

def gen_frames():
    while not terminate_event.is_set():
        if shared_data['current_frame'] is not None:
            ret, buffer = cv2.imencode('.jpg', shared_data['current_frame'])
            if ret:
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        time.sleep(0.03)

def gen_detection():
    while not terminate_event.is_set():
        if shared_data['detection_frame'] is not None:
            ret, buffer = cv2.imencode('.jpg', shared_data['detection_frame'])
            if ret:
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        time.sleep(0.03)

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/detection_feed')
def detection_feed():
    return Response(gen_detection(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/status')
def get_status():
    return json.dumps({'status': shared_data['status'] if shared_data['status'] else '대기 중...'})

def main():
    # 데이터베이스 초기화
    db_conn = init_database()
    if db_conn is None:
        print("데이터베이스 초기화 실패")
        return

    # 시리얼 포트 초기화
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
        print(f"Serial port {SERIAL_PORT} opened successfully.")
        
        # 시리얼 통신 스레드 시작
        serial_thread = threading.Thread(target=serial_read_thread, args=(ser,), daemon=True)
        serial_thread.start()
        
    except serial.SerialException as e:
        print(f"Error opening serial port {SERIAL_PORT}: {e}")
        return

    def process_video():
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Error: Cannot open camera")
            return
        
        crop_info = {"x": 100, "y": 50, "width": 500, "height": 800}
        
        try:
            while not terminate_event.is_set():
                ret, img = cap.read()
                if not ret:
                    continue

                shared_data['current_frame'] = img
                
                if ir_triggered_event.is_set():
                    print("IR 이벤트 처리 중...")
                  
                    time.sleep(0.5)
                    
                    # 이제 컨베이어 정지
                    ser.write(b"0")
                    
                    # 완전히 멈출 때까지 대기
                    time.sleep(0.3)
                    
                    # 이미지 캡처 및 처리
                    ret, img = cap.read()
                    if ret:
                        processed_img = crop_img(img, crop_info) if crop_info else img
                        result = inference_reqeust(processed_img, api_url)
                        
                        if result:
                            processed_img, status = process_frame(processed_img, result)
                            shared_data['detection_frame'] = processed_img
                            shared_data['status'] = status
                            
                            object_counts = {}
                            for obj in result['objects']:
                                if obj['score'] > 0.5:
                                    class_name = obj['class']
                                    object_counts[class_name] = object_counts.get(class_name, 0) + 1
                            save_quality_data(db_conn, status, object_counts)
                    
                    time.sleep(1.2)
                    ser.write(b"1")
                    ir_triggered_event.clear()
                
                time.sleep(0.03)
                
        finally:
            cap.release()
    
    # 비디오 처리 스레드 시작
    video_thread = threading.Thread(target=process_video, daemon=True)
    video_thread.start()
    
    # Flask 서버 시작
    app.run(host='0.0.0.0', port=5000)
    
    # 종료 처리
    terminate_event.set()
    ser.close()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    print("시스템 시작. 웹 브라우저에서 http://localhost:5000 에 접속하세요.")
    main()